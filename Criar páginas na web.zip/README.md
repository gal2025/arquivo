
  # Criar páginas na web

  This is a code bundle for Criar páginas na web. The original project is available at https://www.figma.com/design/HBlp1lpjpUQtPXBWapGo2r/Criar-p%C3%A1ginas-na-web.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  