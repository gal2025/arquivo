import { Link } from "react-router";
import { ArrowRight, Target, Users, Zap, TrendingUp, Award, Shield } from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Home() {
  const features = [
    {
      icon: Target,
      title: "Foco em Resultados",
      description: "Estratégias orientadas a dados para alcançar seus objetivos de negócio.",
    },
    {
      icon: Users,
      title: "Equipe Especializada",
      description: "Profissionais experientes dedicados ao sucesso do seu projeto.",
    },
    {
      icon: Zap,
      title: "Agilidade",
      description: "Metodologias ágeis para entregas rápidas e eficientes.",
    },
    {
      icon: Shield,
      title: "Confiança",
      description: "Segurança e transparência em todos os processos.",
    },
  ];

  const stats = [
    { number: "500+", label: "Projetos Concluídos" },
    { number: "98%", label: "Satisfação do Cliente" },
    { number: "15+", label: "Anos de Experiência" },
    { number: "200+", label: "Clientes Ativos" },
  ];

  const testimonials = [
    {
      name: "Maria Silva",
      role: "CEO, TechCorp",
      content: "A parceria transformou completamente nossa presença digital. Resultados excepcionais em tempo recorde!",
      image: "https://images.unsplash.com/photo-1573497491306-c8a68afac6f2?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaXZlcnNlJTIwYnVzaW5lc3MlMjBwZW9wbGV8ZW58MXx8fHwxNzcyMzg5MzcxfDA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      name: "João Santos",
      role: "Diretor, Inovação S.A.",
      content: "Profissionalismo e qualidade incomparáveis. Superaram todas as nossas expectativas.",
      image: "https://images.unsplash.com/photo-1759844197486-5b3612c7d534?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxkaWdpdGFsJTIwc3RyYXRlZ3klMjBwbGFubmluZ3xlbnwxfHx8fDE3NzIzODkzNzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
    {
      name: "Ana Costa",
      role: "CMO, StartupBR",
      content: "Equipe incrível! Nos ajudaram a escalar nosso negócio de forma estratégica e sustentável.",
      image: "https://images.unsplash.com/photo-1765366417030-16d9765d920a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxidXNpbmVzcyUyMHByb2Zlc3Npb25hbCUyMHdvcmtzcGFjZXxlbnwxfHx8fDE3NzIyOTMxODd8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    },
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-blue-600 via-purple-600 to-pink-500 text-white py-20 lg:py-32">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-4xl lg:text-6xl font-bold mb-6">
                Transforme Seu Negócio com Soluções Inovadoras
              </h1>
              <p className="text-xl mb-8 text-blue-50">
                Impulsionamos empresas com tecnologia de ponta, estratégias inteligentes e resultados mensuráveis.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link
                  to="/contact"
                  className="inline-flex items-center justify-center px-8 py-3 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors"
                >
                  Comece Agora
                  <ArrowRight className="ml-2" size={20} />
                </Link>
                <Link
                  to="/services"
                  className="inline-flex items-center justify-center px-8 py-3 border-2 border-white text-white rounded-lg hover:bg-white hover:text-blue-600 transition-colors"
                >
                  Nossos Serviços
                </Link>
              </div>
            </div>
            <div className="hidden lg:block">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1760611656007-f767a8082758?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjB0ZWFtJTIwbWVldGluZ3xlbnwxfHx8fDE3NzIyODYwNDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Equipe moderna trabalhando"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Por Que Escolher a Gente?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Oferecemos soluções completas e personalizadas para impulsionar seu crescimento.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <div
                  key={index}
                  className="p-6 rounded-xl bg-white shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
                >
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="text-white" size={28} />
                  </div>
                  <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                  <p className="text-gray-600">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Services Preview */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1766740606233-6573571caa6b?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjb3Jwb3JhdGUlMjB0ZWNobm9sb2d5JTIwaW5ub3ZhdGlvbnxlbnwxfHx8fDE3NzIzODkzNjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Tecnologia e inovação"
                className="rounded-2xl shadow-xl"
              />
            </div>
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                Serviços que Geram Impacto Real
              </h2>
              <p className="text-lg text-gray-600 mb-6">
                Combinamos tecnologia avançada com expertise estratégica para entregar resultados excepcionais.
              </p>
              <ul className="space-y-4 mb-8">
                <li className="flex items-start">
                  <TrendingUp className="text-blue-600 mr-3 flex-shrink-0" size={24} />
                  <div>
                    <h4 className="font-semibold mb-1">Consultoria Estratégica</h4>
                    <p className="text-gray-600">Análise profunda e planos de ação personalizados</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <Award className="text-blue-600 mr-3 flex-shrink-0" size={24} />
                  <div>
                    <h4 className="font-semibold mb-1">Excelência Comprovada</h4>
                    <p className="text-gray-600">Projetos premiados e reconhecidos no mercado</p>
                  </div>
                </li>
                <li className="flex items-start">
                  <Zap className="text-blue-600 mr-3 flex-shrink-0" size={24} />
                  <div>
                    <h4 className="font-semibold mb-1">Resultados Rápidos</h4>
                    <p className="text-gray-600">Metodologia ágil para entregas eficientes</p>
                  </div>
                </li>
              </ul>
              <Link
                to="/services"
                className="inline-flex items-center px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Conheça Todos os Serviços
                <ArrowRight className="ml-2" size={20} />
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              O Que Nossos Clientes Dizem
            </h2>
            <p className="text-xl text-gray-600">
              Confiança conquistada através de resultados reais
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div
                key={index}
                className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow"
              >
                <div className="flex items-center mb-4">
                  <ImageWithFallback
                    src={testimonial.image}
                    alt={testimonial.name}
                    className="w-16 h-16 rounded-full object-cover mr-4"
                  />
                  <div>
                    <h4 className="font-semibold">{testimonial.name}</h4>
                    <p className="text-sm text-gray-600">{testimonial.role}</p>
                  </div>
                </div>
                <p className="text-gray-700 italic">"{testimonial.content}"</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Pronto Para Transformar Seu Negócio?
          </h2>
          <p className="text-xl mb-8 text-blue-50">
            Entre em contato e descubra como podemos ajudar sua empresa a alcançar novos patamares.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors text-lg"
          >
            Fale Conosco
            <ArrowRight className="ml-2" size={24} />
          </Link>
        </div>
      </section>
    </div>
  );
}
