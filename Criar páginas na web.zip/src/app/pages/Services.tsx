import { Link } from "react-router";
import { 
  Code, 
  TrendingUp, 
  Megaphone, 
  BarChart3, 
  Smartphone, 
  Cloud,
  Shield,
  Headphones,
  ArrowRight,
  CheckCircle2
} from "lucide-react";
import { ImageWithFallback } from "../components/figma/ImageWithFallback";

export function Services() {
  const services = [
    {
      icon: Code,
      title: "Desenvolvimento Web",
      description: "Websites e aplicações web modernas, responsivas e de alto desempenho.",
      features: [
        "Design responsivo e moderno",
        "Otimização de performance",
        "SEO integrado",
        "Manutenção e suporte contínuo"
      ],
    },
    {
      icon: TrendingUp,
      title: "Consultoria Digital",
      description: "Estratégias personalizadas para transformação digital do seu negócio.",
      features: [
        "Análise de mercado",
        "Planejamento estratégico",
        "Roadmap de implementação",
        "Métricas e KPIs"
      ],
    },
    {
      icon: Megaphone,
      title: "Marketing Digital",
      description: "Campanhas eficazes para aumentar sua presença online e gerar resultados.",
      features: [
        "Gestão de redes sociais",
        "Google Ads e Facebook Ads",
        "Marketing de conteúdo",
        "Email marketing"
      ],
    },
    {
      icon: BarChart3,
      title: "Gestão de Projetos",
      description: "Metodologias ágeis para garantir entregas no prazo e com qualidade.",
      features: [
        "Metodologia Scrum/Kanban",
        "Gestão de recursos",
        "Controle de qualidade",
        "Relatórios de progresso"
      ],
    },
    {
      icon: Smartphone,
      title: "Desenvolvimento Mobile",
      description: "Aplicativos nativos e híbridos para iOS e Android.",
      features: [
        "Apps nativos e híbridos",
        "UX/UI otimizado",
        "Integração com APIs",
        "Publicação nas stores"
      ],
    },
    {
      icon: Cloud,
      title: "Cloud & DevOps",
      description: "Infraestrutura em nuvem e automação de processos de desenvolvimento.",
      features: [
        "Migração para cloud",
        "CI/CD pipeline",
        "Monitoramento 24/7",
        "Otimização de custos"
      ],
    },
  ];

  const processSteps = [
    {
      number: "01",
      title: "Descoberta",
      description: "Entendemos profundamente suas necessidades e objetivos de negócio.",
    },
    {
      number: "02",
      title: "Planejamento",
      description: "Criamos uma estratégia detalhada e roadmap de implementação.",
    },
    {
      number: "03",
      title: "Execução",
      description: "Desenvolvemos e implementamos as soluções com metodologias ágeis.",
    },
    {
      number: "04",
      title: "Entrega",
      description: "Garantimos uma transição suave e treinamento completo do time.",
    },
  ];

  return (
    <div className="bg-white">
      {/* Hero Section */}
      <section className="relative py-20 bg-gradient-to-br from-blue-600 to-purple-600 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto">
            <h1 className="text-4xl lg:text-5xl font-bold mb-6">
              Nossos Serviços
            </h1>
            <p className="text-xl text-blue-50">
              Soluções completas e personalizadas para impulsionar seu negócio no mundo digital.
            </p>
          </div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              return (
                <div
                  key={index}
                  className="bg-white p-8 rounded-xl shadow-lg hover:shadow-xl transition-shadow border border-gray-100"
                >
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-500 to-purple-600 rounded-lg flex items-center justify-center mb-4">
                    <Icon className="text-white" size={28} />
                  </div>
                  <h3 className="text-2xl font-semibold mb-3">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <ul className="space-y-2">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-start text-sm text-gray-700">
                        <CheckCircle2 className="text-green-500 mr-2 flex-shrink-0 mt-0.5" size={16} />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Process Section */}
      <section className="py-20 bg-gradient-to-br from-gray-50 to-blue-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Nosso Processo
            </h2>
            <p className="text-xl text-gray-600">
              Uma metodologia comprovada para garantir o sucesso do seu projeto
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
            {processSteps.map((step, index) => (
              <div key={index} className="text-center">
                <div className="text-6xl font-bold text-blue-200 mb-4">
                  {step.number}
                </div>
                <h3 className="text-xl font-semibold mb-3">{step.title}</h3>
                <p className="text-gray-600">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Specialized Solutions */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
            <div>
              <h2 className="text-3xl lg:text-4xl font-bold mb-6">
                Soluções Especializadas
              </h2>
              <p className="text-lg text-gray-700 mb-6">
                Além dos nossos serviços principais, oferecemos soluções especializadas para necessidades específicas do seu negócio.
              </p>
              <div className="space-y-4">
                <div className="flex items-start">
                  <Shield className="text-blue-600 mr-3 flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h4 className="font-semibold mb-1">Segurança da Informação</h4>
                    <p className="text-gray-600">Proteção de dados e compliance com LGPD</p>
                  </div>
                </div>
                <div className="flex items-start">
                  <Headphones className="text-blue-600 mr-3 flex-shrink-0 mt-1" size={24} />
                  <div>
                    <h4 className="font-semibold mb-1">Suporte Contínuo</h4>
                    <p className="text-gray-600">Equipe dedicada disponível para você</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1760611656007-f767a8082758?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBvZmZpY2UlMjB0ZWFtJTIwbWVldGluZ3xlbnwxfHx8fDE3NzIyODYwNDN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Equipe trabalhando"
                className="rounded-2xl shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Industries */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl lg:text-4xl font-bold mb-4">
              Setores Que Atendemos
            </h2>
            <p className="text-xl text-gray-600">
              Experiência comprovada em diversos segmentos
            </p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              "E-commerce",
              "Saúde",
              "Educação",
              "Finanças",
              "Varejo",
              "Tecnologia",
              "Indústria",
              "Serviços"
            ].map((industry, index) => (
              <div
                key={index}
                className="bg-white p-6 rounded-lg shadow text-center hover:shadow-lg transition-shadow"
              >
                <p className="font-semibold">{industry}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-blue-600 to-purple-600 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl lg:text-4xl font-bold mb-6">
            Vamos Conversar Sobre Seu Projeto?
          </h2>
          <p className="text-xl mb-8 text-blue-50">
            Nossa equipe está pronta para entender suas necessidades e propor as melhores soluções.
          </p>
          <Link
            to="/contact"
            className="inline-flex items-center px-8 py-4 bg-white text-blue-600 rounded-lg hover:bg-blue-50 transition-colors text-lg"
          >
            Entre em Contato
            <ArrowRight className="ml-2" size={24} />
          </Link>
        </div>
      </section>
    </div>
  );
}
